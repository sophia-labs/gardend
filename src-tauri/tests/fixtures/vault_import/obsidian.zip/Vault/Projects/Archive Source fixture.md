---
title: Archive Source fixture
tags: [archive-tag-fixture]
---

See [[Archive Target fixture|target display]] and #loose-tag-fixture.

Also see [[Archive Missing fixture]].
