---
title: 'Quoted Title'
tags:
  - alpha
  - beta
---

Body with [[Target Note#Section|Display]] and #tag1 plus `#code-tag` inline.

```
#fenced-tag
```

![[image.png]] then [[Target Note|]] empty display.
